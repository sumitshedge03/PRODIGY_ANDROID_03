package com.example.stopwatchapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvTimer;
    private Button btnStartPause, btnReset;

    private boolean isRunning = false;
    private long startTimeInMillis = 0L;
    private long elapsedTimeInMillis = 0L; // total time when paused

    private Handler handler = new Handler();
    private Runnable updateRunnable = new Runnable() {
        @Override
        public void run() {
            long currentTime = System.currentTimeMillis();
            long totalElapsed = elapsedTimeInMillis;
            if (isRunning) {
                totalElapsed += (currentTime - startTimeInMillis);
            }

            updateTimerText(totalElapsed);

            // update every 50 milliseconds
            handler.postDelayed(this, 50);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTimer = findViewById(R.id.tvTimer);
        btnStartPause = findViewById(R.id.btnStartPause);
        btnReset = findViewById(R.id.btnReset);

        updateTimerText(0);
        startUpdating();

        btnStartPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });
    }

    private void startUpdating() {
        handler.post(updateRunnable);
    }

    private void startTimer() {
        if (!isRunning) {
            startTimeInMillis = System.currentTimeMillis();
            isRunning = true;
            btnStartPause.setText("Pause");
        }
    }

    private void pauseTimer() {
        if (isRunning) {
            long currentTime = System.currentTimeMillis();
            elapsedTimeInMillis += (currentTime - startTimeInMillis);
            isRunning = false;
            btnStartPause.setText("Start");
        }
    }

    private void resetTimer() {
        isRunning = false;
        elapsedTimeInMillis = 0L;
        startTimeInMillis = System.currentTimeMillis();
        updateTimerText(0);
        btnStartPause.setText("Start");
    }

    private void updateTimerText(long millis) {
        int minutes = (int) (millis / 1000) / 60;
        int seconds = (int) (millis / 1000) % 60;
        int milliseconds = (int) (millis % 1000);

        String timeFormatted = String.format("%02d:%02d:%03d", minutes, seconds, milliseconds);
        tvTimer.setText(timeFormatted);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateRunnable);
    }
}
